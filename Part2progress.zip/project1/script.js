window.onload=function myOnloadFunctionPart2(){
var part2Scene1 = document.getElementById("part2Scene1");
var part2Scene2 = document.getElementById("part2Scene2");
var part2Scene3 = document.getElementById("part2Scene3");


var slider = document.getElementById("windowSlider");
var vscene1window = document.getElementById("scene1window");

vscene1window.addEventListener("animationend",postAnimationScene1);

function postAnimationScene1(){
part2Scene1.style.display= "none";
}
    
}
